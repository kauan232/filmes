
// Need for Speed,12,Acão/Crime
// Gran Turismo:De Jogador a Corredor,12,Acão/Esport
// Django Livre,16,Faroeste/Acão
// Arremessando Alto,12,Esporte/Comédia
// Corra!,14,Terror/Comédia
// Nós,16,Terror/Mistério
// Ma,16,Terror/Drama
// A Visita,14,Terror/Documentário
// Sorria,14,Terror/Mistério
// Paranoia,14,Thriller/Mistério

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
